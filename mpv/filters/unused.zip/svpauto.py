import logging
import os
import multiprocessing
import math
import sys
from fractions import Fraction
from subprocess import call
import vapoursynth as vs

core = vs.get_core(threads=(multiprocessing.cpu_count()))
core.max_cache_size = 10400
core.set_max_cache_size(10400)

clip       = video_in
src_fps    = container_fps if container_fps>0.1 else 23.976
target_fps = 60

if round(src_fps*1000)/1000 == 23.810: #Fix for incorrect container_fps provided by MPV on Crunchyroll encodes causing audio desync
	src_fps = 23.976


enable_interpolation = 1
demo_mode   = 0
stereo_type = 0


########## SVP Config ##########
target_fr	 = -1
int_autoscale	 = True
allow_downscale	 = False
block_size		 = int(math.pow(2, round(math.log2(clip.width//80))))
block_size		 = 32 if block_size > 32 else (8 if block_size < 8 else block_size)
pixel_precision	 = 2 if clip.width < 2000 else 1
block_overlap	 = 2 if clip.width < 2000 else 1 
fine_search_type = 4 if clip.width < 2000 else 3
course_search_type = 3
distance		= -12 if clip.width < 2000 else -8
	
if target_fr < 0:
	target_fr = target_fps / math.fabs(target_fr)

fps_scale = math.fabs(target_fr)/src_fps

if int_autoscale:
	fps_scale = int(fps_scale)

if not allow_downscale and fps_scale < 1:
	fps_scale = 1

fps_scale_fraction = Fraction(fps_scale).limit_denominator(1000)

refine_params = "[{thsad:200,search:{distance:" + str(distance//2) + "}},{thsad:200,search:{distance:" + str(distance//4) + "}}]" if clip.width > 1280 else "[{thsad:200,search:{distance:" + str(distance//2) + "}}]"

if clip.width>=2000:
	refine_params = "[]"

super_params     = "{pel:" + str(pixel_precision) + ",scale:{up:2,down:4},gpu:1}"
analyse_params   = "{block:{w:" + str(block_size) + ",h:" + str(block_size) + ",overlap:" + str(block_overlap) + "},main:{search:{distance:" + str(distance) + ",type:" + str(fine_search_type) + ",sort:true,satd:false,coarse:{distance:" + str(distance*2) + ",type:" + str(course_search_type) + ",satd:true,trymany:true,bad:{sad:1500,range:-48}}},penalty:{pzero:0}},refine:" + refine_params + "}"
smoothfps_params = "{debug:{vectors:false},rate:{abs:false,num:" + str(fps_scale_fraction.numerator) + ",den:" + str(fps_scale_fraction.denominator) + "},algo:23,cubic:1,gpuid:0,block:false,linear:true,mask:{area:70,cover:50,area_sharp:1.0},scene:{mode:0,blend:false,limits:{zero:200,blocks:50}}}"

########## BEGIN OF base.py ##########
# This file is a part of SmoothVideo Project (SVP) ver. Nihil
# This is NOT the full Vapoursynth script, all used variables are defined via
# JScript code that generates the full script text.

def interpolate(clip):
# DO NOT REMOVE this comment
# input_um - original frame in 4:2:0
# input_m  - cropped and resized (if needed) frame
# input_m8 - input_m converted to 8-bit
    input_um = clip.resize.Bicubic(format=vs.YUV420P10, dither_type="error_diffusion") 
    input_m = input_um
    input_m8 = input_m.resize.Point(format=vs.YUV420P8)

    super   = core.svp1.Super(input_m8,super_params)
    vectors = core.svp1.Analyse(super["clip"],super["data"],input_m8,analyse_params)
    smooth  = core.svp2.SmoothFps(input_m,super["clip"],super["data"],vectors["clip"],vectors["data"],smoothfps_params,src=input_um,fps=src_fps)
    smooth  = core.std.AssumeFPS(smooth,fpsnum=smooth.fps_num,fpsden=smooth.fps_den)

    if demo_mode==1:
        return demo(input_m,smooth)
    else:
        return smooth

if enable_interpolation != 1:
	smooth = clip
elif stereo_type == 1:
    lf = interpolate(core.std.CropRel(clip,0,(int)(clip.width/2),0,0))
    rf = interpolate(core.std.CropRel(clip,(int)(clip.width/2),0,0,0))
    smooth = core.std.StackHorizontal([lf, rf])
elif stereo_type == 2:
    lf = interpolate(core.std.CropRel(clip,0,0,0,(int)(clip.height/2)))
    rf = interpolate(core.std.CropRel(clip,0,0,(int)(clip.height/2),0))
    smooth = core.std.StackVertical([lf, rf])
else:
    smooth =  interpolate(clip)
########### END OF base.py ###########


smooth.set_output()