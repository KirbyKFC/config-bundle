local speed=1

function round(number)
    return math.floor(number + 0.5)
end

function roundone(number)
    return math.floor(number * 10 + 0.5) / 10
end

function main(name, fps)
    if (fps == nil) then
        return
    end
    local dfps = round(mp.get_property_native("display-fps"))
    mp.set_property_number("sub-fps", dfps)
    speed = roundone(fps / dfps)
    mp.osd_message(speed)
    mp.set_property_number("sub-speed", speed)
end

function start()
    mp.unobserve_property(start)
    local test = mp.get_property("container-fps")
    if (test == nil or test == "nil property unavailable") then
        test = mp.get_property("estimated-vf-fps")
        if (test == nil or test == "nil property unavailable") then
            return
        end
        mp.observe_property("estimated-vf-fps", "number", main)
    else
        mp.observe_property("container-fps", "number", main)
    end
end

-- Wait until we get a video fps.
function check()
    mp.observe_property("estimated-vf-fps", "string", start)
end

mp.register_event("file-loaded", check)
